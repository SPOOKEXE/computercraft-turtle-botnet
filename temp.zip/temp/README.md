
# CC Turtle Botnet - Crafty Turtle

- connect to turtles in computercraft via websocket
- communicate commands to the turtles and receive feedback from them.
- automate the survival and reproduction of turtles via behavior trees and other methods.

https://minecraft.fandom.com/wiki/Ore
