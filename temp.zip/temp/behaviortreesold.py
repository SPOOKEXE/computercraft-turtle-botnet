
from __future__ import annotations

import traceback

from copy import deepcopy
from dataclasses import dataclass, field
from random import randint
from threading import Thread
from typing import Any, Callable
from enum import Enum
from uuid import uuid4
from time import sleep

class BaseBehaviorTree:

	def _internal_update_sequencer_item( self, sequence_item : BaseSequenceItem ) -> None:
		'''
		Internally update the behavior tree sequence item.
		'''

		# print(sequence_item.currentNodeId, sequence_item.nextNodeCache)

		currentNodeId : BehaviorTreeNode = None
		try:
			currentNodeId = sequence_item.nextNodeCache.pop(0)
		except:
			if sequence_item.wrapToRoot:
				currentNodeId = self.rootNode.id # starting off with no node
			else:
				sequence_item.isCompleted = True
				return

		sequence_item.currentNodeId = currentNodeId

		try:
			print( self._idToNode )
			currentNode = self._idToNode[currentNodeId]
		except:
			raise ValueError('Could not find node from id:', currentNodeId) # currentNode = self.rootNode

		sequence_item.currentNodeId = currentNodeId
		condArgs = sequence_item.conditionAutoParams!=None and sequence_item.conditionAutoParams or []
		funcArgs = sequence_item.functionAutoParams!=None and sequence_item.functionAutoParams or []

		if currentNode.nextNode != None:
			sequence_item.nextNodeCache.insert( 0, currentNode.nextNode.id )

		print( currentNode.type )

		if currentNode.type == NodeEnums.Action:

			currentNode.action( self, sequence_item, *funcArgs )

		elif currentNode.type == NodeEnums.MultiAction:

			for action in currentNode.action:
				action( self, sequence_item, *funcArgs )

		elif currentNode.type == NodeEnums.ConditionSwitch:

			index : int = currentNode.condition( self, sequence_item, *condArgs )
			assert type(index) == int, 'ConditionSwitch condition callback did not return a number: ' + self.uid
			assert index < len(currentNode.branches), 'Returned index is out of bounds: ' + self.uid
			value : Callable | str = currentNode.branches[index]

			print(index, value)

			if callable(value) == True:
				value(self, sequence_item, *funcArgs)
			elif type(value) == str and self._idToNode.get(value) != None:
				sequence_item.nextNodeCache.insert( 0, value )
			elif type(value) == BehaviorTreeNode and value != currentNode:
				print('send to new behavior tree node')
				sequence_item.nextNodeCache.insert( 0, value.id )

		elif currentNode.type == NodeEnums.ConditionTrueFalse:

			trueFalse : bool = currentNode.condition( self, sequence_item, *condArgs )
			value : Callable | str = trueFalse==True and currentNode.if_true_branch or currentNode.if_false_branch
			if callable(value) == True:
				value(self, sequence_item, *funcArgs)
			elif type(value) == str and self._idToNode.get(value) != None:
				sequence_item.nextNodeCache.insert( 0, value )
			elif type(value) == BehaviorTreeNode:
				print('send to new behavior tree node')
				sequence_item.nextNodeCache.insert( 0, value.id )

		elif currentNode.type == NodeEnums.ConditionWhileTrue:

			value : bool = currentNode.condition( self, sequence_item, *condArgs )
			while value == True:
				currentNode.callback( self, sequence_item, *funcArgs )
				value = currentNode.condition( self, sequence_item, *condArgs )

		elif currentNode.type == NodeEnums.RandomSwitch:

			randomIndex : int = randint(0, len(currentNode.branches) - 1)
			try: value = currentNode.branches[randomIndex]
			except: value = None

			if callable(value) == True:
				value(self, sequence_item, *funcArgs)
			elif type(value) == str and self._idToNode.get(value) != None:
				sequence_item.nextNodeCache.insert(0, value)
			elif type(value) == BehaviorTreeNode:
				print('send to new behavior tree node')
				sequence_item.nextNodeCache.insert( 0, value.id )

		elif currentNode.type == NodeEnums.HookBehaviorTree:

			previous_wrapRoot = sequence_item.wrapToRoot
			currentNode.behavior_tree.append_sequencer( sequence_item )

			sequence_item.wrapToRoot = False
			currentNode.behavior_tree.await_sequencer_completion( sequence_item )

			sequence_item.wrapToRoot = previous_wrapRoot

		elif currentNode.type == NodeEnums.PassToBehaviorTree:

			# mutate before popping
			if currentNode.mutator != None: currentNode.mutator( self, sequence_item )
			self.pop_sequencer( sequence_item )
			currentNode.behavior_tree.append_sequencer( sequence_item )

		else:
			print("NodeEnum is not implemented: ", currentNode.type.name )

class BehaviorTreeBuilder:

	@staticmethod
	def _search_nested_for_ids( node : BehaviorTreeNode, cache : list = [] ) -> list[str]:
		if node == None or callable(node) == True or array_find( cache, node.id ) != -1:
			return cache
		cache.append(node.id)
		if node.type == NodeEnums.ConditionSwitch or node.type == NodeEnums.RandomSwitch:
			for branch in node.branches:
				BehaviorTreeBuilder._search_nested_for_ids( branch, cache=cache )
		elif node.type == NodeEnums.ConditionTrueFalse:
			BehaviorTreeBuilder._search_nested_for_ids( node.if_true_branch, cache=cache )
			BehaviorTreeBuilder._search_nested_for_ids( node.if_false_branch, cache=cache )
		return cache

	@staticmethod
	def _search_nested_fill_links( node : BehaviorTreeNode, parent : BehaviorTreeNode | None = None, cache : list = [] ) -> None:
		'''
		Edit all the nodes within the target tree
		'''
		if node == None or callable(node) == True:
			return

		# check parent
		if parent != None:
			if parent.childIDs == None: parent.childIDs = []
			if array_find( parent.childIDs, node.id ) == -1:
				parent.childIDs.append(node.id)

		# check if node was already searched
		if array_find( cache, node.id ) != -1: return
		cache.append(node.id)

		if node.childIDs == None:
			node.childIDs = []
		if node.parentIDs == None:
			node.parentIDs = []

		if parent != None and array_find(node.parentIDs, parent.id) == -1:
			node.parentIDs.append( parent.id )

		if node.type == NodeEnums.ConditionSwitch or node.type == NodeEnums.RandomSwitch:
			for branch in node.branches:
				BehaviorTreeBuilder._search_nested_fill_links( branch, parent=node, cache=cache )
		elif node.type == NodeEnums.ConditionTrueFalse:
			BehaviorTreeBuilder._search_nested_fill_links( node.if_true_branch, parent=node, cache=cache )
			BehaviorTreeBuilder._search_nested_fill_links( node.if_false_branch, parent=node, cache=cache )

		nextnode : BehaviorTreeNode = node.nextNode
		if nextnode != None:
			if nextnode.childIDs == None: nextnode.childIDs = []
			if nextnode.parentIDs == None: nextnode.parentIDs = []
			if array_find( nextnode.parentIDs, node.id ) == -1: nextnode.parentIDs.append( node.id )
			if array_find( node.childIDs, nextnode.id ) == -1: node.childIDs.append( nextnode.id )

	@staticmethod
	def _convert_nested_to_array( root : BehaviorTreeNode ) -> list:

		node_array : list[BehaviorTreeNode] = []

		def search( node : BehaviorTreeNode ) -> None:
			nonlocal node_array

			if node == None or callable(node) == True or array_find(node_array, node) != -1:
				return
			node_array.append(node)

			if node.type == NodeEnums.ConditionSwitch or node.type == NodeEnums.RandomSwitch:
				list_of_branches = node.branches#[0]
				if type(list_of_branches) == list:
					node.branches = [ branch.id for branch in list_of_branches ]
					for branch in list_of_branches:
						search(branch)
			elif node.type == NodeEnums.ConditionTrueFalse:
				trueBranch = node.if_true_branch
				falseBranch = node.if_false_branch
				if type(trueBranch) == BehaviorTreeNode:
					node.if_true_branch = trueBranch.id
				if type(falseBranch) == BehaviorTreeNode:
					node.if_false_branch = falseBranch.id
				search( trueBranch )
				search( falseBranch )

			nnode = node.nextNode
			if nnode != None:
				node.nextNode = nnode.id
				search(nnode)

		search(root)
		return node_array

	@staticmethod
	def build_from_nested_dict( root : BehaviorTreeNode, uuid : str = uuid4().hex ) -> BaseBehaviorTree:
		root = deepcopy(root)
		# deep search for nodes and get all of their ids
		# _ = BehaviorTreeBuilder._search_nested_for_ids( root )
		# deep search nodes and compute child/parent links.
		BehaviorTreeBuilder._search_nested_fill_links( root )
		# create a node array
		nodeArray : list[BehaviorTreeNode] = BehaviorTreeBuilder._convert_nested_to_array( root )
		# return a new behavior tree
		return BaseBehaviorTree(uid=uuid, nodes=nodeArray)

# tests
if __name__ == '__main__':

	from time import sleep

	def p1(_, __): print('1')
	def p2(_, __) : print('2')
	def p3(_, __) : print('3')

	def print_extra( _, __ ): print('wowzie')

	bt : BaseBehaviorTree = BehaviorTreeBuilder.build_from_nested_dict(
		TreeNodeFactory.condition_truefalse_node(
			lambda _, __ : randint(0, 1) == 0,
			TreeNodeFactory.random_switch_node([ p1, p2, p3 ], None),
			print_extra,
			None
		)
	)

	seq_item = bt.create_sequencer_item()
	bt.append_sequencer( seq_item )

	print("STEP START")
	hasBeenToRoot = False
	steps = 1
	while seq_item.currentNodeId != bt.rootNode.id or not hasBeenToRoot:
		if seq_item.currentNodeId == bt.rootNode.id: hasBeenToRoot = True
		bt.update_sequencer_items()
		bt.await_sequencer_completion(seq_item)
		print(seq_item)
		steps += 1
	print(f"REACHED ROOT AFTER {steps} steps.")
