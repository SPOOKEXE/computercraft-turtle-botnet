
# THE PLAN

starting fuel = 1 coal block
1 coal block = 800 fuel = 800 blocks

FIND FUEL IN 720 BLOCKS (either find a tree or coal)

#### 1. Get someone to setup the turtle.

i. craft these items:
- turtle
- crafting table
- iron pickaxe
- coal block (9 coal)

ii. place down the turtle with crafting table, iron pickaxe and coal block inside the turtle's inventory.
iii. download pastebin code to drive and name as startup
iv. reboot turtle

#### 2. Automation & Reproduction:

TURTLEBRIAN.txt
