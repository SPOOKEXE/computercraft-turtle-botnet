
- Websocket to connect to turtle.
- 3D World Viewer & Database

- Place Block
- Break Block
- Craft Items
- Refuel
- Display Current Fuel Level
- Show Block Name on Mouse Hover
- Drop Items
- Change Inventory
- Inspect chest inventory
- Grab items from chest
- Move items in/from inventory
- Equip Items
- Interface with peripherals
- Interface for unique blocks (craft table, furnace, anvil, enchant table, etc)

- Objectives (find fuel, explore, aim to get a block)
- Pathfinding?


MAJOR NOTE:
- may need to save the current state (job list + current index) of the
turtle in the turtle so it can continue off where it was when the
turtle chunk is UNLOADED (assuming no chunk loader in turtle).
- https://www.youtube.com/watch?v=U7HWMfgPGxo
