
## Execution Tree

1. Get or generate a turtle id from backend.
	i. use the turtle label to store it

2. Start the execution tree;
	i. backend tells the turtle what to do
	ii. the turtle tells the server its response
	iii. can have prebuilt bulk operations such as "read_surroundings" which returns a list of the surrounding parts.

3. Endless loop for behavior tree system on backend.
