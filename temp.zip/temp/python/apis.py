
import json
import traceback

from typing import Any

from library.websocks import BaseWebSocket
from library.ccturtle import TurtleAPI, BehaviorTrees, Turtle
from library.minecraft import Point3, World
from library.recipes import RECIPES, resolve_multi_tree
from library.behaviortree import BaseSequenceItem
from websockets.server import WebSocketServerProtocol

class TurtleSequencer:

	def __init__( self, world : World, turtle : Turtle ):
		self.world = world
		self.turtle = turtle
		self.sequencer = BehaviorTrees.INITIALIZER.create_sequencer_item(
			conditionAutoParams = [ turtle, world ],
			functionAutoParams = [ turtle, world ]
		)

world = World()
turtle = Turtle()
sequencer = BaseSequenceItem(
	wrapToRoot = False,
	conditionAutoParams = [ turtle, world ],
	functionAutoParams = [ turtle, world ],
	data = { },
)

BehaviorTrees.INITIALIZER.start_auto_updater()

BehaviorTrees.INITIALIZER.append_sequencer( sequencer )
BehaviorTrees.INITIALIZER.await_sequencer_completion( sequencer )

print( 'COMPLETED!' )

BehaviorTrees.INITIALIZER.pop_sequencer( sequencer )

BehaviorTrees.INITIALIZER.stop_auto_updater()

# socket = CCTurtleHost(world=world)
# socket.start()
