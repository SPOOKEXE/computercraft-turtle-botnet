
world = World()
turtle = Turtle()
sequencer = BaseSequenceItem(
	wrapToRoot = False,
	conditionAutoParams = [ turtle, world ],
	functionAutoParams = [ turtle, world ],
	data = { },
)

BehaviorTrees.INITIALIZER.start_auto_updater()
BehaviorTrees.INITIALIZER.append_sequencer( sequencer )
BehaviorTrees.INITIALIZER.await_sequencer_completion( sequencer )

print( 'COMPLETED!' )

BehaviorTrees.INITIALIZER.pop_sequencer( sequencer )
BehaviorTrees.INITIALIZER.stop_auto_updater()

# socket = CCTurtleHost(world=world)
# socket.start()
