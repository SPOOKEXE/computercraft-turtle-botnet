
from __future__ import annotations

from uuid import uuid4
from time import sleep, time
from uuid import uuid4
from time import sleep

from library.minecraft import Point3, World, Turtle, TurtleActions, WorldAPI
from library.behaviortree import BaseBehaviorTree, BehaviorTreeBuilder, BaseSequenceItem, TreeNodeFactory
from library.recipes import RECIPES, resolve_multi_tree, resolve_recipe_tree

# WHITELISTED_BLOCKS = {
# 	# block_name : max_quantity
# 	'minecraft:cobblestone' : 32,
# 	'minecraft:redstone' : 64,
# 	'minecraft:lapis_lazuli' : 64,
# 	'minecraft:iron_ingot' : 64,
# 	'minecraft:sand' : 64,

# 	'minecraft:chest' : 4,
# }

class ERROR_MESSAGES:
	NO_DESIGNATED_ORE = 'Turtle {} has no designated ore target.'
	UNKNOWN_DESIGNATED_ORE = 'Turtle {} has an unknown designated ore target: {}'
	MINING_FAILED_TO_REACH_Y_LEVEL = 'Turtle {} failed to mine to the Y level - exiting MINE_ORE_RESOURCE tree.'

class BehaviorFunctions:

	# count the amount of a specific item in the inventory
	def COUNT_INVENTORY_ITEMS( turtle : Turtle ) -> dict:
		inventory_mapping = {}
		for (item_id, amount) in turtle.inventory: increment_dictionary( inventory_mapping, item_id, amount )
		if turtle.left_hand != None: increment_dictionary( inventory_mapping, turtle.left_hand.name, turtle.left_hand.quantity )
		if turtle.right_hand != None: increment_dictionary( inventory_mapping, turtle.right_hand.name, turtle.right_hand.quantity )
		return inventory_mapping

	# does the turtle have the items in its inventory / equipped?
	def HAS_ITEMS_IN_INVENTORY( turtle : Turtle, items : list[tuple[str, int]] ) -> bool:
		# map the inventory
		inventory_mapping = BehaviorFunctions.COUNT_INVENTORY_ITEMS( turtle )
		# check requirements
		for (item_id, amount) in items:
			if inventory_mapping.get(item_id) == None or inventory_mapping.get(item_id) < amount:
				return False
		return True # has requirements

	# set target resource
	def SET_TARGET_ORE( seq : BaseSequenceItem, block : str, amount : int ) -> None:
		seq.data['target_ore'] = (block, amount)

	# get the ore resource information
	def FIND_ORE_RESOURCE_INFO( block_id : str ) -> dict | None:
		return ORE_LEVEL_CONSTANTS.get(block_id)

	# go to Y level
	def MINE_TO_Y_LEVEL( turtle : Turtle, y_level : int ) -> bool:
		if y_level == turtle.position.y: return True # already here
		distance = abs( y_level - turtle.position.y )
		if y_level < turtle.position.y:
			jobs = [ [TurtleActions.digBelow], [TurtleActions.down] ] * distance
		else:
			jobs = [ [TurtleActions.digAbove], [TurtleActions.up] ] * distance
		tracker_id = TurtleAPI.send_tracked_jobs(turtle, jobs)
		success, results = TurtleAPI.yield_tracked_results( turtle, tracker_id, timeout=10 + int(distance * 1.5) )
		if (not success) or (False in results):
			print( turtle.uid, 'failed to dig to y-level ' + y_level )
			index = results.index(False)
			print('Failed on instruction enumeration:', jobs[index])
			return False
		return True

# MAIN BEHAVIOR LOOPS
class BehaviorTrees:
	BREAK_ORE_VEIN : BaseBehaviorTree
	DIG_TUNNEL : BaseBehaviorTree
	MINE_ORE_RESOURCE : BaseBehaviorTree

	LOW_FUEL_RESOLVER : BaseBehaviorTree

	# FIND_SURFACE_RESOURCE : BaseBehaviorTree
	# FIND_UNDERGROUND_RESOURCE : BaseBehaviorTree
	# FIND_TARGET_RESOURCE : BaseBehaviorTree

	# CRAFT_TARGET_RESOURCE : BaseBehaviorTree
	# SMELT_TARGET_RESOURCE : BaseBehaviorTree
	# FARM_TREE_SAPLING : BaseBehaviorTree

	MAIN_LOOP : BaseBehaviorTree
	INITIALIZER : BaseBehaviorTree

BehaviorTrees.BREAK_ORE_VEIN = BehaviorTreeBuilder.build_from_nested_dict(

)
BehaviorTrees.DIG_TUNNEL = BehaviorTreeBuilder.build_from_nested_dict(

)

def _3_condition_switch( _, __, seq : BaseSequenceItem, ___ ) -> int:
	if type(seq.data.get('target_ore')) != tuple: return 1
	yHeight = ORE_LEVEL_CONSTANTS.get(seq.data['target_ore'][0])
	if yHeight == None: return 2
	seq.data['target_height'] = yHeight
	return 3

BehaviorTrees.MINE_ORE_RESOURCE = BehaviorTreeBuilder.build_from_nested_dict(

	TreeNodeFactory.condition_switch_node(
		_3_condition_switch,
		# no target ore selected
		TreeNodeFactory.action_node(
			lambda _, __, ___, turtle : print(ERROR_MESSAGES.NO_DESIGNATED_ORE.format(turtle.uid)),
			None
		),
		# could not find the ore y-level
		TreeNodeFactory.action_node(
			lambda _, __, ___, turtle : print( ERROR_MESSAGES.NO_DESIGNATED_ORE.format(turtle.uid, turtle.data['target_ore'][0]) ),
			None
		),
		# ore was found, proceed with mining (go to y level first then mine)
		TreeNodeFactory.condition_truefalse_node(
			# mine to the target Y level
			lambda _, seq, __, turtle : BehaviorFunctions.MINE_TO_Y_LEVEL( turtle, seq.data.get('target_height') ),
			# while hasn't achieved total goal, keep mining until low-fuel (if not getting coal) or goal has been achieved.
			TreeNodeFactory.while_condition_node(
				lambda *args : True,
				lambda _, __, ___, ____ : None,
				None
			),
			lambda _, __, ___, turtle : print(ERROR_MESSAGES.MINING_FAILED_TO_REACH_Y_LEVEL.format(turtle.uid)),
			None
		)
	)
)

def _4_switch_condition( _, __, ___, turtle : Turtle ) -> int:
	inventory_mapping = BehaviorFunctions.COUNT_INVENTORY_ITEMS( turtle )
	if inventory_mapping.get('minecraft:coal') == None:
		# no coal, go mining
		return 3
	if inventory_mapping.get('minecraft:coal') >= 9:
		if inventory_mapping.get('minecraft:chest') >= 1:
			return 2 # craft a coal block then consume it
		return 1 # burn the coal in inventory and dont worry about crafting a coal block
	# coal is in the inventory but its not enough so keep mining
	return 3

BehaviorTrees.LOW_FUEL_RESOLVER = BehaviorTreeBuilder.build_from_nested_dict(

	TreeNodeFactory.condition_switch_node(
		_4_switch_condition,
		[
			# burn the coal in the inventory
			None,
			# craft coal blocks then burn the coal block
			None,
			# mine for coal then come back again
			TreeNodeFactory.hook_behavior_tree(
				BehaviorTrees.MINE_ORE_RESOURCE,
				lambda _, seq, __, ___ : BehaviorFunctions.SET_TARGET_ORE(seq, 'minecraft:coal_ore', 27), # get tons of coal
				None
			),
		],
		None
	)

)
